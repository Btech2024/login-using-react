import LoginForm from "./components/loginform";

function App() {
  return (
    <div className="page">
      <LoginForm />
    </div>
  );
}

export default App;
